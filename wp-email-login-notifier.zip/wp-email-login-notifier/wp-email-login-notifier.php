<?php
/*
Plugin Name: Email Login Notifier
Description: Sends an email to users when a login occurs from a new device or IP address.
Version: 1.0
Author: Webloop
License: GPL2
*/

// Prevent direct access to this file
if (!defined('ABSPATH')) {
    exit;
}

// Create database table on plugin activation
function eln_install() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'known_ips';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id mediumint(9) NOT NULL,
        ip_address varchar(100) NOT NULL,
        last_login datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'eln_install');

// Check IP and send email on login
function eln_check_login($user_login, $user) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'known_ips';
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $user_id = $user->ID;
    $user_email = $user->user_email;
    $site_name = get_bloginfo('name');
    $site_url = get_site_url();

    // Check if this IP is known for the user
    $known_ip = $wpdb->get_var($wpdb->prepare(
        "SELECT ip_address FROM $table_name WHERE user_id = %d AND ip_address = %s",
        $user_id,
        $ip_address
    ));

    if (!$known_ip) {
        // New IP detected, send email
        $subject = __('New Device Login Notification', 'email-login-notifier');
        $message = sprintf(
            __("Hello %s,\n\nA new login to your account was detected from IP address: %s\n\nDate: %s\nSite: %s\n\nIf this was not you, please secure your account immediately by changing your password.\n\nThank you,\n%s Team", 'email-login-notifier'),
            $user->display_name,
            $ip_address,
            current_time('mysql'),
            $site_url,
            $site_name
        );

        wp_mail($user_email, $subject, $message);

        // Store the new IP in the database
        $wpdb->insert(
            $table_name,
            array(
                'user_id' => $user_id,
                'ip_address' => $ip_address,
                'last_login' => current_time('mysql'),
            ),
            array('%d', '%s', '%s')
        );
    } else {
        // Update last login time for known IP
        $wpdb->update(
            $table_name,
            array('last_login' => current_time('mysql')),
            array('user_id' => $user_id, 'ip_address' => $ip_address),
            array('%s'),
            array('%d', '%s')
        );
    }
}
add_action('wp_login', 'eln_check_login', 10, 2);

// Add admin page for viewing known IPs
function eln_admin_menu() {
    add_menu_page(
        'Known Login IPs',
        'Login IPs',
        'manage_options',
        'eln-known-ips',
        'eln_admin_page',
        'dashicons-email-alt',
        81
    );
}
add_action('admin_menu', 'eln_admin_menu');

function eln_admin_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'known_ips';
    $results = $wpdb->get_results(
        "SELECT k.ip_address, k.last_login, u.display_name 
         FROM $table_name k 
         JOIN {$wpdb->users} u ON k.user_id = u.ID 
         ORDER BY k.last_login DESC LIMIT 50"
    );
    ?>
    <div class="wrap">
        <h1>Known Login IPs</h1>
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>User</th>
                    <th>IP Address</th>
                    <th>Last Login</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($results as $row) : ?>
                    <tr>
                        <td><?php echo esc_html($row->display_name); ?></td>
                        <td><?php echo esc_html($row->ip_address); ?></td>
                        <td><?php echo esc_html($row->last_login); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
}
?>